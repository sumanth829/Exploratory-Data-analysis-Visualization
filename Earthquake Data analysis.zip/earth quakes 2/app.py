from shiny import App, ui, render
from shinywidgets import output_widget, render_widget
import plotly.express as px
import pandas as pd
import os

# Assuming you have a DataFrame `df` with the necessary data
dataset_location = './Earthquakes'
file_name = 'quakes-cleaned.csv'

df = pd.read_csv('quakes-cleaned.csv')

app_ui = ui.page_fluid(
        ui.panel_main(
            output_widget("mean_mag_by_location_source"),
            output_widget("top_locations"),
            output_widget("scatter_geo"),
            output_widget("hist_depth"),
            output_widget("Earthquake_Types"),
        )
    )

def server(input, output, session):
    @output
    @render_widget
    def mean_mag_by_location_source():
        mean_mag_by_location_source = df.groupby('locationSource')['mag'].mean().reset_index()
        fig = px.bar(mean_mag_by_location_source, x='locationSource', y='mag', title='Mean Magnitude of Earthquakes by locationSource')
        return fig

    @output
    @render_widget
    def top_locations():
        region_stats = df.groupby('locationSource')['mag'].agg(['mean', 'count']).sort_values(by='mean', ascending=False)
        top_locations = region_stats.head(10).reset_index()
        fig = px.scatter(top_locations, x='locationSource', y='mean', size='count', color='mean',
                         title=f'Top {10} locationSource with Highest Average Magnitude and Count of Earthquakes',
                         labels={'locationSource': 'Location Source', 'mean': 'Mean Magnitude', 'count': 'Number of Earthquakes'})
        return fig

    @output
    @render_widget
    def scatter_geo():
        top_coordinates = df.groupby(['latitude', 'longitude']).size().idxmax()
        latitude, longitude = top_coordinates
        fig = px.scatter_geo(df, lat='latitude', lon='longitude', title='Latitude and Longitude with the Highest Frequency of Earthquakes',
                             labels={'latitude': 'Latitude', 'longitude': 'Longitude'},
                             hover_data=['depth', 'mag'], color='mag')
        return fig

    @output
    @render_widget
    def hist_depth():
        depth_distribution = df['depth']
        fig = px.histogram(depth_distribution, nbins=30, title='Distribution of Earthquake Depths',
                           labels={'value': 'Depth'},
                           marginal='rug', opacity=0.7)
        return fig

    @output
    @render_widget
    def earthquake_Type():
        # Insight 5: Distribution of Earthquake Types
        earthquake_types_distribution = df['type'].value_counts().reset_index()

        fig = px.pie(earthquake_types_distribution, names='type', values='count',
                    title='Distribution of Earthquake Types', hole=0.5)
        return fig

app = App(app_ui, server)

if __name__ == "__main__":
    app.run()
